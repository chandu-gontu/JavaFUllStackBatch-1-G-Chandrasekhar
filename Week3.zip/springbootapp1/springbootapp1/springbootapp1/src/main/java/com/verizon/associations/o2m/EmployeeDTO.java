package com.verizon.associations.o2m;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;

public class EmployeeDTO {
	
	 Integer eid;
	 @NotNull
	 String name;
	 @Max(100000)
	 Integer salary;
	 DepartmentDTO departmentDto;
	 public EmployeeDTO(){
		 
	 }
	public Integer getEid() {
		return eid;
	}
	public void setEid(Integer eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	public DepartmentDTO getDepartmentDto() {
		return departmentDto;
	}
	public void setDepartmentDto(DepartmentDTO departmentDto) {
		this.departmentDto = departmentDto;
	}
	 
	
}
