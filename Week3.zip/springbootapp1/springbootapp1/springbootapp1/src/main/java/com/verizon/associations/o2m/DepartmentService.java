package com.verizon.associations.o2m;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class DepartmentService {
	@Autowired
	DepartmentDao departmentDao;
	
	public void  addDepartment(DepartmentDTO departmentDto) {
		
		
		Department department=new Department();
		department.setDid(departmentDto.getDid());
		department.setDname(departmentDto.getDname());
		
		departmentDao.save(department);
	}
}
