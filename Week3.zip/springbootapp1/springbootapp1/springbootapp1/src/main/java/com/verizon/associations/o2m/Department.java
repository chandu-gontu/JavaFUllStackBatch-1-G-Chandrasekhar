package com.verizon.associations.o2m;


import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
@Entity
@Table(name="departments")
public class Department {
	@Id
	private Integer did;
	@Column
	private String dname;
	public Department(){
		
	}
	public Department(Integer did, String dname) {
		super();
		this.did = did;
		this.dname = dname;
		
	}

	public Integer getDid() {
		return did;
	}
	public void setDid(Integer did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}

	@Override
	public String toString() {
		return "Department [did=" + did + ", dname=" + dname + "]";
	}
	
	
	
	
	 @OneToMany(fetch = FetchType.LAZY, mappedBy = "department" , cascade =
	 CascadeType.ALL) private Set<Employee> employees;// = new HashSet<>();
	 
	 
	 public Set<Employee> getEmployees() { return employees; }
	 
	 public void setEmployees(Set<Employee> employees) { this.employees =
	 employees; }
	
	 
	 
	 
	//the method below will add employee to department 
	//also serves the purpose to avoid cyclic references. 
	/*
	 * public void addEmployee(Employee employee) { employee.setDepartment(this);
	 * //this will avoid nested cascade this.getEmployees().add(employee); }
	 */

}
