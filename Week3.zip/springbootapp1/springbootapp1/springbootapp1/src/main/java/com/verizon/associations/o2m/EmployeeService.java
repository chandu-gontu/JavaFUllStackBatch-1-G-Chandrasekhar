package com.verizon.associations.o2m;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class EmployeeService {
	
	@Autowired
	EmployeeDao employeeDao;
	
	public void  addEmployee(EmployeeDTO employeeDto) {
		Employee employee=new Employee();
		employee.setEid(employeeDto.getEid());
		employee.setName(employeeDto.getName());
		employee.setSalary(employeeDto.getSalary());
		
		Department department=new Department();
		department.setDid(employeeDto.getDepartmentDto().getDid());
		department.setDname(employeeDto.getDepartmentDto().getDname());
		employee.setDepartment(department);
		employeeDao.save(employee);
	}
	
	public List<EmployeeDTO> getAllEmployees(){
		List<Employee> elist=employeeDao.findAll();
		List<EmployeeDTO> elist1=new ArrayList<>();
		for(Employee e: elist) {
			  EmployeeDTO employeeDTO=new EmployeeDTO();
			   employeeDTO.setEid(e.getEid());
			   employeeDTO.setName(e.getName());
			   employeeDTO.setSalary(e.getSalary());
			   DepartmentDTO departmentDTO=new DepartmentDTO();
			   departmentDTO.setDid(e.getDepartment().getDid());
			   departmentDTO.setDname(e.getDepartment().getDname());
			   employeeDTO.setDepartmentDto(departmentDTO);
			   elist1.add(employeeDTO);
			
		}
		return elist1;
	}

}
