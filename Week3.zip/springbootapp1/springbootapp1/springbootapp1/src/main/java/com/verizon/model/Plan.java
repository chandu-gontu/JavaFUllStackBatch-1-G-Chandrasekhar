package com.verizon.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
//@Table(name="productPlan")
public class Plan {
	@Id
	Integer pid;
	@Column
	@NotNull //(message="plan name cannot be null")
	//@NotBlank(message="Cannot be blank")
	//@Size(min=5,max=8)
	String pname;
	//@Max(20)
	Integer duration;
	Plan(){
	}
	public Plan(Integer pid, String pname, Integer duration) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "Plan [pid=" + pid + ", pname=" + pname + ", duration=" + duration + "]";
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	
	

}
