package com.verizon.associations.o2o;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	@Autowired
	StudentService studentService;
	@PostMapping("/student")
	public String addStudent(@RequestBody Student student)
	{ String result=null;
		
	
		studentService.addStudent(student);
		 result= "success";
		
		return result;
	}
	
	
	@GetMapping("/student")
	public List<Student> getAllStudents(){
		return studentService.getAllStudents();
	}
	
	/* {
       "studentId":1, 
	    "name":"ram",
        "address": {

            "addressId":101,
            "street":"madhapur",
             "city":"hyderabad",
             "zipCode":"500081"
            }
      }
    
    */

}
