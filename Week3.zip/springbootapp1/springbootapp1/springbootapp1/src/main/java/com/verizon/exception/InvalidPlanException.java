package com.verizon.exception;

public class InvalidPlanException extends Exception {
	
public	InvalidPlanException(String msg){
		super(msg);
	}
}
