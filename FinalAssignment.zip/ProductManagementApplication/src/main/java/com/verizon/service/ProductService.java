package com.verizon.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.ProductDao;
import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductService {
	@Autowired
	ProductDao productDao;

	public String addProduct(Product product) {
		productDao.save(product);
		return "Added";
	}

	public List<Product> getProducts() {
		List<Product> productList = productDao.findAll();
		return productList;
	}

	public Product getProduct(Integer pid) {
		Product product = productDao.findById(pid).get();
		if(product == null)
			throw new ProductNotFoundException("Oops Product cannot be found with given ID");
		return product;
	}

	public List<Product> getProductsBetweenLowHigh(Integer low, Integer high) {
		List<Product> productList = productDao.findProductsBetweenLowHigh(low, high);
		return productList;
	}

	public Product updateProduct(Integer pid, Product product) {
		Product product1 = productDao.findById(pid).get();
		if(product1 == null)
			throw new ProductNotFoundException("Oops Product cannot be found with given ID");
		product1.setPrice(product.getPrice());
		return product1;
	}

	public Product deleteProduct(Integer pid) {
		Product prod = productDao.findById(pid).get();
		if(prod == null) {
			throw new ProductNotFoundException("Oops Product cannot be found with given ID");
		}
		productDao.deleteById(pid);
		return prod;
	
}}
