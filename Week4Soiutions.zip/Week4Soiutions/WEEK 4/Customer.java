class Customer{
String name;

Customer(String name){
this.name=name;
}

void displayCustomer(){
System.out.println(this.name);
}
public static void main(String Args[]){
Customer c=new Customer("EXCITED for WEEK 4");
c.displayCustomer();
}
}