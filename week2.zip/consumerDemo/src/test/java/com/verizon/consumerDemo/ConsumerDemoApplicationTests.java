package com.verizon.consumerDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
